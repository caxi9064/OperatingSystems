#!/bin/bash
#Ejemplo de funciones.
# Las funciones tienen el formato
#  nombre () {
#    instrucciones
#  }
#  No se ponen par�metros entre los ()
#
# Se invocan colocando el nombre de la funci�n en shell script
#
#

mensaje (){
  echo Ejecuci�n del programa que calcula la media
}

# Si se necesitan par�mentros, estos se almacenar�n en $1, $2,...
# y se pasan a la funcion colocandolos despu�s de su nombre en la invocaci�n

media () {
 media=`expr $1 + $2`
 media=`expr $media / 2`
 echo $media
}
# si hay que devolver par�metros la funci�n puede hacer un echo para devolverlos
# el programa principla tiene que recogerlos igual que recoje el resultado de la ejecuci�n de un comando.
suma () {
 res=`expr $1 + $2`
 echo $res
}

mensaje
echo Datos para calcular la media 4 6 
media 4 6
sum=`suma 5 7`
echo La suma de 5 y 7 es $sum
