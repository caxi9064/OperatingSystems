#!/bin/bash
#Ejemplo de bucle while:
# while [ condicion ]
# do
#   instrucciones a repetir mientras la condici�n es verdadera
# done

n=1
while [ $n -le 9 ]
do
   echo $n
   n=`expr $n + 1`
done 

