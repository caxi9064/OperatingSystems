#!/bin/bash
# Programa que muestra el nombre de los ficheros pasados como par�metros y su contenido
for i in $* 
do
  echo FICHERO $i
  more $i
done

