#!/bin/bash
#Programa que muestra los nombres de los ficheros del directorio actual y su contenido
listaficheros=`ls`
for i in $listaficheros 
do
  echo FICHERO $i
  more $i
done

