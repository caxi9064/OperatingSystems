#!/bin/bash
#Este programa pide 2 n�meros y una operaci�n (+,-, *, /) por teclado y muestra el resultado de realizar esa operaci�n sobre los 2 n�meros
#Jos� Manuel P�rez Lobato
echo dar 1� numero
read n1
echo dar 2� numero
read n2
echo dar operacion "(+, -, *, /)"
read opc
case $opc in
+) res=`expr $n1 + $n2` ;;
-) res=`expr $n1 - $n2` ;;
"*") res=`expr $n1 \* $n2` ;;
/) res=`expr $n1 / $n2` ;;
*) echo Operaci�n incorrecta
esac 
echo resultado $res
