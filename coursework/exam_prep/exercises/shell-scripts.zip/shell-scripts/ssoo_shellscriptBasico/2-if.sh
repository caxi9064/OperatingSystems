#!/bin/bash
# Ejemplos de uso de la sintasis del if 

echo valor primer parametro = $1
if [ "$1" = "uno" ]; then 
  echo el primer parametro es uno
else
  echo el primer parametro NO es uno
fi

v=3;
condicion=`test $v -eq 3`
echo La comparacion de v y el 3 da: $condicion
if [ $v -eq 3 ]
then
 echo Vale 3
fi
v="Juan"
if [ $v != Juan ]
then
 echo no Vale Juan
else
 echo  Vale Juan
fi


