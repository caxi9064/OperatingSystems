#!/bin/bash
# Ejemplo de utilizaci�n del bucle for. Formato.
# for variable in listadevalores
# do
# instrucciones que se van a repetir. Se ejecutar�n una vez por cada valor de la lista de valores.
# done
for i in 1 2 3 4 5 6 7 8 9 
do
  echo $i
done

