#!/bin/bash
# Programa que muestra el nombre de los ficheros del directorio actual  y su contenido sin utilizar una variable intermedia

for i in `ls` 
do
  echo FICHERO $i
  more $i
done

