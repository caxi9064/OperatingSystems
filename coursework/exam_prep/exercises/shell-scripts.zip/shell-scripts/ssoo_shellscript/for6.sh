

#Ejemplo de for como lista de otro for
#Programa que muestra el contenido de los par�metros recibidos que son directorios
for i in ` for i in \`ls\`  
           do
	      if [ -d $i ]
	      then
	        echo $i
	      fi
	   done`
do
  echo CONTENIDO DEL DIRECTORIO $i
  ls $i 
done
