

ficheros=`ls $1`
for i in $ficheros
do
  if [ -f $1/$i ]
  then
    echo ------------$i---------- :
    head -3 $1/$i
  fi 
done
