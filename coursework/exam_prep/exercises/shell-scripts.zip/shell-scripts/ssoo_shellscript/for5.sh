

# Comprueba si los usuarios dados como par�metro son usuarios autorizados dle sistema
for i  
do
  grep $i /etc/passwd &>/dev/null && echo $i est� autorizado
done

