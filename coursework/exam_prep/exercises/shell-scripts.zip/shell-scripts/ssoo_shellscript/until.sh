

#Ejemplo de utilizaci�n del bucle until. Formato:
# until [ condici�n ]
# do
# instrucciones que se repiten mientras la condici�n sea falsa.
# done

n=1
#until ! [ $n -le 9 ]
until [ $n -eq 10 ]
do
   echo $n
   n=`expr $n + 1`
done 

