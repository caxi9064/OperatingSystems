
echo "Responda si o no"
read resp
case $resp in
[Ss]*) echo Ha respondido afirmativamente.;;
[Nn]*) echo Ha respondido negativamente.;;
*) echo respuesta incorrecta
esac

